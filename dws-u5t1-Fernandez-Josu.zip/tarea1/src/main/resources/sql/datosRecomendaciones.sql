INSERT INTO recomendaciones (id,observaciones,idcliente)
VALUES
  (1,"Quisque nonummy ipsum non arcu. Vivamus sit amet risus. Donec egestas. Aliquam nec",1),
  (2,"Nullam velit dui, semper et, lacinia vitae,",2),
  (3,"mi felis, adipiscing fringilla, porttitor vulputate, posuere vulputate, lacus. Cras interdum.",3),
  (4,"diam at pretium aliquet, metus urna convallis",4),
  (5,"Fusce fermentum fermentum arcu. Vestibulum ante ipsum primis in faucibus orci luctus et",5),
  (6,"ligula tortor, dictum eu, placerat eget, venenatis a,",6),
  (7,"ac nulla. In tincidunt congue turpis. In condimentum. Donec at arcu. Vestibulum ante",7),
  (8,"ligula tortor, dictum eu, placerat eget, venenatis a, magna. Lorem ipsum dolor sit amet,",8),
  (9,"molestie pharetra nibh. Aliquam ornare, libero at auctor ullamcorper, nisl arcu iaculis enim,",9),
  (10,"sem eget massa. Suspendisse eleifend. Cras sed leo.",10);
INSERT INTO recomendaciones (id,observaciones,idcliente)
VALUES
  (11,"velit. Sed malesuada augue ut lacus. Nulla tincidunt,",11),
  (12,"netus et malesuada fames ac turpis egestas. Fusce",12),
  (13,"vitae, sodales at, velit. Pellentesque ultricies dignissim lacus. Aliquam rutrum",13),
  (14,"vitae sodales nisi magna sed dui. Fusce aliquam,",14),
  (15,"hendrerit id, ante. Nunc mauris sapien, cursus in, hendrerit",15),
  (16,"at, nisi. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Proin",16),
  (17,"nisl arcu iaculis enim, sit amet ornare lectus justo eu arcu. Morbi sit amet",17),
  (18,"mollis dui, in sodales elit",18),
  (19,"facilisis lorem tristique aliquet. Phasellus fermentum convallis ligula. Donec luctus aliquet",19),
  (20,"ornare placerat, orci lacus vestibulum lorem,",20);
  
COMMIT;