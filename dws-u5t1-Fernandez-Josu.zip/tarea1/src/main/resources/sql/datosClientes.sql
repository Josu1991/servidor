INSERT INTO clientes (id,nif,nombre,apellidos,claveseguridad,email)
VALUES
  (1,"44999594K","Keiko","Meadows",1732,"meadowskeiko6933@icloud.net"),
  (2,"28553744Y","Whoopi","Phelps",4488,"w-phelps@aol.ca"),
  (3,"25861374E","Hilary","Mcmahon",5418,"hmcmahon6589@google.org"),
  (4,"12242423G","Hunter","Frederick",1332,"h_frederick@icloud.edu"),
  (5,"51724739D","Diana","Dickerson",5053,"d-dickerson5965@aol.net");
  
INSERT INTO clientes (id,nif,nombre,apellidos,claveseguridad,email)
VALUES
  (6,"13176696D","Amber","Ramirez",2375,"amber.ramirez6505@protonmail.org"),
  (7,"82568848H","Chava","Floyd",3011,"cfloyd@hotmail.couk"),
  (8,"03768520L","Tatum","Walsh",2463,"walsh_tatum2491@outlook.couk"),
  (9,"51976869H","Ezekiel","Woodard",2707,"e-woodard@icloud.couk"),
  (10,"55172493N","Coby","Lester",9856,"c-lester7681@hotmail.couk");  
  
INSERT INTO clientes (id,nif,nombre,apellidos,claveseguridad,email)
VALUES
  (11,"48037186R","Brielle","Howard",7848,"b_howard@aol.com"),
  (12,"71227610F","Candace","Bates",4990,"c-bates@google.org"),
  (13,"41124626J","Eagan","Carpenter",2060,"e_carpenter9768@outlook.org"),
  (14,"86926685Y","Yvette","Slater",6646,"yslater@google.edu"),
  (15,"18829162J","Heather","Abbott",9983,"abbottheather@hotmail.org");  
  
INSERT INTO clientes (id,nif,nombre,apellidos,claveseguridad,email)
VALUES
  (16,"10159358C","Kessie","Rich",4285,"k_rich804@google.net"),
  (17,"61816073X","Keelie","Forbes",1844,"k-forbes1767@hotmail.com"),
  (18,"27682739N","Dale","Glass",2545,"gdale@google.ca"),
  (19,"91124511M","Farrah","Farmer",5208,"farrah-farmer6033@hotmail.com"),
  (20,"21865746E","Graham","Casey",6223,"g.casey3482@google.com");  
  
COMMIT;