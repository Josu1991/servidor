package com.example.tarea1.controllers;

import com.example.tarea1.models.Recomendacion;
import com.example.tarea1.services.RecomendacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/recomendaciones")
public class RecomendacionController {

    @Autowired
    private RecomendacionService recomendacionService;

    @GetMapping
    public String listarRecomendaciones(Model model) {
        List<Recomendacion> recomendaciones = recomendacionService.obtenerTodos();
        model.addAttribute("recomendaciones", recomendaciones);
        return "recomendaciones/index";
    }

    @GetMapping("/crear")
    public String formularioCrearRecomendacion(Model model) {
        model.addAttribute("recomendacion", new Recomendacion());
        return "recomendaciones/create";
    }

    @PostMapping
    public String guardarRecomendacion(@ModelAttribute Recomendacion recomendacion) {
        recomendacionService.guardar(recomendacion);
        return "redirect:/recomendaciones";
    }

    @GetMapping("/editar/{id}")
    public String formularioEditarRecomendacion(@PathVariable int id, Model model) {
        Recomendacion recomendacion = recomendacionService.obtenerPorId(id);
        model.addAttribute("recomendacion", recomendacion);
        return "recomendaciones/edit";
    }

    @PostMapping("/editar/{id}")
    public String actualizarRecomendacion(@PathVariable int id, @ModelAttribute Recomendacion recomendacion) {
        recomendacionService.actualizar(id, recomendacion);
        return "redirect:/recomendaciones";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarRecomendacion(@PathVariable int id) {
        recomendacionService.eliminar(id);
        return "redirect:/recomendaciones";
    }
}
