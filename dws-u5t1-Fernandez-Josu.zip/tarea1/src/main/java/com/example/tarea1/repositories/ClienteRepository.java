package com.example.tarea1.repositories;

import com.example.tarea1.models.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Integer> {
    List<Cliente> findByNif(String nif);

    List<Cliente> findByNombreContaining(String nombre);
}
