package com.example.tarea1.controllers;

import com.example.tarea1.models.Movimiento;
import com.example.tarea1.services.MovimientoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/movimientos")
public class MovimientoController {

    @Autowired
    private MovimientoService movimientoService;

    @GetMapping
    public String listarMovimientos(Model model) {
        List<Movimiento> movimientos = movimientoService.obtenerTodos();
        model.addAttribute("movimientos", movimientos);
        return "movimientos/index";
    }

    @GetMapping("/crear")
    public String formularioCrearMovimiento(Model model) {
        model.addAttribute("movimiento", new Movimiento());
        return "movimientos/create";
    }

    @PostMapping
    public String guardarMovimiento(@ModelAttribute Movimiento movimiento) {
        movimientoService.guardar(movimiento);
        return "redirect:/movimientos";
    }

    @GetMapping("/editar/{id}")
    public String formularioEditarMovimiento(@PathVariable int id, Model model) {
        Movimiento movimiento = movimientoService.obtenerPorId(id);
        model.addAttribute("movimiento", movimiento);
        return "movimientos/edit";
    }

    @PostMapping("/editar/{id}")
    public String actualizarMovimiento(@PathVariable int id, @ModelAttribute Movimiento movimiento) {
        movimientoService.actualizar(id, movimiento);
        return "redirect:/movimientos";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarMovimiento(@PathVariable int id) {
        movimientoService.eliminar(id);
        return "redirect:/movimientos";
    }
}
