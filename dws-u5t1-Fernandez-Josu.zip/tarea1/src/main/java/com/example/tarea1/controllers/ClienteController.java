package com.example.tarea1.controllers;

import com.example.tarea1.models.Cliente;
import com.example.tarea1.services.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/clientes")
public class ClienteController {
	@Autowired
	private ClienteService clienteService;
	
	@GetMapping
	public String listarClientes(Model model) {
        List<Cliente> clientes = clienteService.obtenerTodos();
		model.addAttribute("clientes", clientes);
		return "clientes/index";
	}
	
	@GetMapping("/crear")
	public String formularioCrearCliente(Model model) {
		model.addAttribute("cliente", new Cliente());
		return "clientes/create";
	}
	
	@PostMapping
	public String guardarCliente(@ModelAttribute Cliente cliente) {
		clienteService.guardar(cliente);
		return "redirect:/clientes";
	}
	
	@PostMapping("/editar/{id}")
	public String actualizarCliente(@PathVariable int id, @ModelAttribute Cliente cliente) {
		clienteService.actualizar(id, cliente);
		return "redirect:/clientes";
	}
	
	@GetMapping("/eliminar/{id}")
	public String eliminarCliente(@PathVariable int id) {
		clienteService.eliminar(id);
		return "redirect:/clientes";
	}
}
