package com.example.tarea1.models;

import jakarta.persistence.*;

@Entity 
@Table(name="recomendaciones")
public class Recomendacion {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@Column(nullable=false, length=500)
	private String observaciones;
		
	@ManyToOne
	@JoinColumn(name="idcliente",nullable=false)
	private Cliente cliente;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getObservaciones() {
		return observaciones;
	}

	public void setObservaciones(String observaciones) {
		this.observaciones = observaciones;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
		
}
