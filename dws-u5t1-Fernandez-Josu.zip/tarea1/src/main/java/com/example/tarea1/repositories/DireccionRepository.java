package com.example.tarea1.repositories;

import com.example.tarea1.models.Direccion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DireccionRepository extends JpaRepository<Direccion, Integer> {
    List<Direccion> findByPais(String pais);

    List<Direccion> findByCp(String cp);
}
