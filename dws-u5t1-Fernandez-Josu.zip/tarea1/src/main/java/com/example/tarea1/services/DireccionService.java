package com.example.tarea1.services;

import com.example.tarea1.models.Direccion;
import com.example.tarea1.repositories.DireccionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DireccionService {

    @Autowired
    private DireccionRepository direccionRepository;

    public List<Direccion> obtenerTodos() {
        return direccionRepository.findAll();
    }

    public Direccion obtenerPorId(int id) {
        return direccionRepository.findById(id).orElse(null);
    }

    public void guardar(Direccion direccion) {
        direccionRepository.save(direccion);
    }

    public void actualizar(int id, Direccion direccionActualizada) {
        Direccion direccion = obtenerPorId(id);
        if (direccion != null) {
            direccion.setDescripcion(direccionActualizada.getDescripcion());
            direccion.setPais(direccionActualizada.getPais());
            direccion.setCp(direccionActualizada.getCp());
            direccionRepository.save(direccion);
        }
    }

    public void eliminar(int id) {
        direccionRepository.deleteById(id);
    }
}
