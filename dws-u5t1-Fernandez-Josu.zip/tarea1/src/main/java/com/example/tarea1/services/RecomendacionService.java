package com.example.tarea1.services;

import com.example.tarea1.models.Recomendacion;
import com.example.tarea1.repositories.RecomendacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RecomendacionService {

    @Autowired
    private RecomendacionRepository recomendacionRepository;

    public List<Recomendacion> obtenerTodos() {
        return recomendacionRepository.findAll();
    }

    public Recomendacion obtenerPorId(int id) {
        return recomendacionRepository.findById(id).orElse(null);
    }

    public void guardar(Recomendacion recomendacion) {
        recomendacionRepository.save(recomendacion);
    }

    public void actualizar(int id, Recomendacion recomendacionActualizada) {
        Recomendacion recomendacion = obtenerPorId(id);
        if (recomendacion != null) {
            recomendacion.setObservaciones(recomendacionActualizada.getObservaciones());
            recomendacionRepository.save(recomendacion);
        }
    }

    public void eliminar(int id) {
        recomendacionRepository.deleteById(id);
    }
}
