package com.example.tarea1.services;

import com.example.tarea1.models.Cuenta;
import com.example.tarea1.repositories.CuentaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CuentaService {

    @Autowired
    private CuentaRepository cuentaRepository;

    public List<Cuenta> obtenerTodos() {
        return cuentaRepository.findAll();
    }

    public Cuenta obtenerPorId(int id) {
        return cuentaRepository.findById(id).orElse(null);
    }

    public void guardar(Cuenta cuenta) {
        cuentaRepository.save(cuenta);
    }

    public void actualizar(int id, Cuenta cuentaActualizada) {
        Cuenta cuenta = obtenerPorId(id);
        if (cuenta != null) {
            cuenta.setBanco(cuentaActualizada.getBanco());
            cuenta.setSucursal(cuentaActualizada.getSucursal());
            cuenta.setDc(cuentaActualizada.getDc());
            cuenta.setNumeroCuenta(cuentaActualizada.getNumeroCuenta());
            cuenta.setSaldoActual(cuentaActualizada.getSaldoActual());
            cuentaRepository.save(cuenta);
        }
    }


    public void eliminar(int id) {
        cuentaRepository.deleteById(id);
    }
}
