package com.example.tarea1.services;

import com.example.tarea1.models.Movimiento;
import com.example.tarea1.repositories.MovimientoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovimientoService {

    @Autowired
    private MovimientoRepository movimientoRepository;

    public List<Movimiento> obtenerTodos() {
        return movimientoRepository.findAll();
    }

    public Movimiento obtenerPorId(int id) {
        return movimientoRepository.findById(id).orElse(null);
    }

    public void guardar(Movimiento movimiento) {
        movimientoRepository.save(movimiento);
    }

    public void actualizar(int id, Movimiento movimientoActualizado) {
        Movimiento movimiento = obtenerPorId(id);
        if (movimiento != null) {
            movimiento.setTipo(movimientoActualizado.getTipo());
            movimiento.setFechaOperacion(movimientoActualizado.getFechaOperacion());
            movimiento.setDescripcion(movimientoActualizado.getDescripcion());
            movimiento.setImporte(movimientoActualizado.getImporte());
            movimientoRepository.save(movimiento);
        }
    }


    public void eliminar(int id) {
        movimientoRepository.deleteById(id);
    }
}

