package com.example.tarea1.controllers;

import com.example.tarea1.models.Cuenta;
import com.example.tarea1.services.CuentaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/cuentas")
public class CuentaController {

    @Autowired
    private CuentaService cuentaService;

    @GetMapping
    public String listarCuentas(Model model) {
        List<Cuenta> cuentas = cuentaService.obtenerTodos();
        model.addAttribute("cuentas", cuentas);
        return "cuentas/index";
    }

    @GetMapping("/crear")
    public String formularioCrearCuenta(Model model) {
        model.addAttribute("cuenta", new Cuenta());
        return "cuentas/create";
    }

    @PostMapping
    public String guardarCuenta(@ModelAttribute Cuenta cuenta) {
        cuentaService.guardar(cuenta);
        return "redirect:/cuentas";
    }

    @GetMapping("/editar/{id}")
    public String formularioEditarCuenta(@PathVariable int id, Model model) {
        Cuenta cuenta = cuentaService.obtenerPorId(id);
        model.addAttribute("cuenta", cuenta);
        return "cuentas/edit";
    }

    @PostMapping("/editar/{id}")
    public String actualizarCuenta(@PathVariable int id, @ModelAttribute Cuenta cuenta) {
        cuentaService.actualizar(id, cuenta);
        return "redirect:/cuentas";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarCuenta(@PathVariable int id) {
        cuentaService.eliminar(id);
        return "redirect:/cuentas";
    }
}
