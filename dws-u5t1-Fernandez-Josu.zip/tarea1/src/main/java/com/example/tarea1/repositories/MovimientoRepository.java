package com.example.tarea1.repositories;

import com.example.tarea1.models.Movimiento;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MovimientoRepository extends JpaRepository<Movimiento, Integer> {
    List<Movimiento> findByTipo(String tipo);

    List<Movimiento> findByIdCuentaOrigen(Integer idCuentaOrigen);

    List<Movimiento> findByIdCuentaDestino(Integer idCuentaDestino);
}
