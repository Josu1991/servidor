package com.example.tarea1.repositories;

import com.example.tarea1.models.Recomendacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RecomendacionRepository extends JpaRepository<Recomendacion, Integer> {
    Recomendacion findByIdCliente(Integer idCliente);
}
