package com.example.tarea1.repositories;

import com.example.tarea1.models.Cuenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CuentaRepository extends JpaRepository<Cuenta, Integer> {
    List<Cuenta> findByIdCliente(Integer idCliente);

    List<Cuenta> findBySaldoActualGreaterThan(Double saldo);
}
