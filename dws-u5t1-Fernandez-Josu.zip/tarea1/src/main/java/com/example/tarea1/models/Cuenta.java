package com.example.tarea1.models;

import jakarta.persistence.*;

@Entity
@Table(name = "cuentas")
public class Cuenta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false, length = 4)
    private String banco;

    @Column(nullable = false, length = 4)
    private String sucursal;

    @Column(nullable = false, length = 2)
    private String dc;

    @Column(nullable = false, length = 10)
    private String numerocuenta;

    @Column(nullable = false)
    private float saldoactual;

    @ManyToOne
    @JoinColumn(name = "idcliente", nullable = false)
    private Cliente cliente;
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getBanco() {
        return banco;
    }

    public void setBanco(String banco) {
        this.banco = banco;
    }

    public String getSucursal() {
        return sucursal;
    }

    public void setSucursal(String sucursal) {
        this.sucursal = sucursal;
    }

    public String getDc() {
        return dc;
    }

    public void setDc(String dc) {
        this.dc = dc;
    }

    public String getNumeroCuenta() {
        return numerocuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numerocuenta = numeroCuenta;
    }

    public double getSaldoActual() {
        return saldoactual;
    }

    public void setSaldoActual(double saldoActual) {
        this.saldoactual = (float) saldoActual;
    }

    
}
