package com.example.tarea1.controllers;
import com.example.tarea1.models.Direccion;
import com.example.tarea1.services.DireccionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/direcciones")
public class DireccionController {

    @Autowired
    private DireccionService direccionService;

    @GetMapping
    public String listarDirecciones(Model model) {
        List<Direccion> direcciones = direccionService.obtenerTodos();
        model.addAttribute("direcciones", direcciones);
        return "direcciones/index";
    }

    @GetMapping("/crear")
    public String formularioCrearDireccion(Model model) {
        model.addAttribute("direccion", new Direccion());
        return "direcciones/create";
    }

    @PostMapping
    public String guardarDireccion(@ModelAttribute Direccion direccion) {
        direccionService.guardar(direccion);
        return "redirect:/direcciones";
    }

    @GetMapping("/editar/{id}")
    public String formularioEditarDireccion(@PathVariable int id, Model model) {
        Direccion direccion = direccionService.obtenerPorId(id);
        model.addAttribute("direccion", direccion);
        return "direcciones/edit";
    }

    @PostMapping("/editar/{id}")
    public String actualizarDireccion(@PathVariable int id, @ModelAttribute Direccion direccion) {
        direccionService.actualizar(id, direccion);
        return "redirect:/direcciones";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarDireccion(@PathVariable int id) {
        direccionService.eliminar(id);
        return "redirect:/direcciones";
    }
}