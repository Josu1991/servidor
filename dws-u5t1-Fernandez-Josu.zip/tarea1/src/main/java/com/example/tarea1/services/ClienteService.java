package com.example.tarea1.services;

import com.example.tarea1.models.Cliente;
import com.example.tarea1.repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository clienteRepository;

    public List<Cliente> obtenerTodos() {
        return clienteRepository.findAll();
    }

    public Cliente obtenerPorId(int id) {
        return clienteRepository.findById(id).orElse(null);
    }

    public void guardar(Cliente cliente) {
        clienteRepository.save(cliente);
    }

    public void actualizar(int id, Cliente clienteActualizado) {
        Cliente cliente = obtenerPorId(id);
        if (cliente != null) {
            cliente.setNombre(clienteActualizado.getNombre());
            cliente.setApellidos(clienteActualizado.getApellidos());
            cliente.setNif(clienteActualizado.getNif());
            cliente.setEmail(clienteActualizado.getEmail());
            clienteRepository.save(cliente);
        }
    }

    public void eliminar(int id) {
        clienteRepository.deleteById(id);
    }
}
